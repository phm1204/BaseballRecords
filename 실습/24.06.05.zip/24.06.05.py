import pymysql

db = pymysql.connect(
    host = 'localhost',
    port = 3306,
    user = 'root',
    passwd = '1204',
    db = 'ecommerce',
    charset = 'utf8'
)
cursor = db.cursor()

for index in range(10):
    product_code = 215673140 + index + 1
    sql = """insert into product values('""" + str(product_code)+ """',
    '스위트바니 여름신상5900원~롱원피스티셔츠./긴팔/반팔',23000, 6900, 70, 'F'
    );
    """
    print(sql)
    cursor.execute(sql)

db.commit()
db.close()
